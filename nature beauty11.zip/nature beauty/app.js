const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mysql = require("mysql");
const path = require("path");

const cors = require("cors");
const port = 5500;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(express.static(__dirname));
app.use(cors());
app.use("/images", express.static(path.join(__dirname, "assets/images")));

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "naturebeauty",
});

connection.connect((err) => {
    if (err) {
        console.error("Error connecting to MySQL database: " + err.stack);
        return;
    }
    console.log("Connected to MySQL database as id " + connection.threadId);
});

app.get("/api/collections", (req, res) => {
    const query = "SELECT * FROM COLLECTION";

    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.json(results);
    });
});

app.get("/api/products", (req, res) => {
    const query = "SELECT * FROM PRODUCT";

    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.json(results);
    });
});

app.get("/api/favorites", (req, res) => {
    const query = "SELECT * FROM FAVORITE";

    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.json(results);
    });
});

app.delete("/api/favorites", (req, res) => {
    const query = "DELETE FROM FAVORITE";

    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.status(200).json({message: "Favorites cleared"});
    });
});

app.delete("/api/cart", (req, res) => {
    const query = "DELETE FROM CART";

    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.status(200).json({message: "Cart items cleared"});
    });
});

app.get("/api/cart", (req, res) => {
    const query = "SELECT * FROM CART";
    
    connection.query(query, (err, results) => {
        if (err) {
            console.error("Error executing query: " + err.stack);
            res.status(500).json({ error: "Failed to fetch data" });
            return;
        }
        res.json(results);
    });
});

app.post("/api/add-to-wishlist", (req, res) => {
    const { id, pname, stars, reviews, originalprice, actualprice, image, discount } = req.body;

    // Check if the item already exists in the favorites table
    const checkQuery = "SELECT * FROM favorite WHERE id = ?";
    connection.query(checkQuery, [id], (checkErr, checkResults) => {
        if (checkErr) {
            console.error("Error checking for item in favorites table: " + checkErr.stack);
            res.status(500).json({ message: "Failed to check item in wishlist" });
            return;
        }

        if (checkResults.length > 0) {
            // If item already exists in favorites, send a message indicating it's already added
            res.status(200).json({ message: "Item already added to wishlist" });
        } else {
            // If item doesn't exist in favorites, proceed to add it

            connection.query(
                "INSERT INTO favorite (id, pname, stars, reviews, originalprice, actualprice, image, discount) VALUES (?, ?,?,?,?,?,?,?)",
                [id, pname, stars, reviews, originalprice, actualprice, image, discount],
                (err, result) => {
                    if (err) {
                        console.error("Error inserting into favorites table: " + err.stack);
                        res.status(500).json({ message: "Failed to add item to wishlist" });
                        return;
                    }
                    res.status(200).json({ message: "Item added to wishlist successfully" });
                }
            );
        }
    });
});
app.post("/api/add-to-cart", (req, res) => {
    const { id, pname, actualprice, image } = req.body;

    // Check if the item already exists in the favorites table
    const checkQuery = "SELECT * FROM cart WHERE id = ?";
    connection.query(checkQuery, [id], (checkErr, checkResults) => {
        if (checkErr) {
            console.error("Error checking for item in cart table: " + checkErr.stack);
            res.status(500).json({ message: "Failed to check item in cart" });
            return;
        }

        if (checkResults.length > 0) {
            // If item already exists in favorites, send a message indicating it's already added
            res.status(200).json({ message: "Item already added to cart" });
        } else {
            // If item doesn't exist in favorites, proceed to add it

            connection.query(
                "INSERT INTO cart (id, pname, actualprice, image) VALUES (?, ?,?,?)",
                [id, pname, actualprice, image],
                (err, result) => {
                    if (err) {
                        console.error("Error inserting into cart table: " + err.stack);
                        res.status(500).json({ message: "Failed to add item to cart" });
                        return;
                    }
                    res.status(200).json({ message: "Item added to cart successfully" });
                }
            );
        }
    });
});
process.on("exit", () => {
    connection.end((err) => {
        if (err) {
            console.error("Error closing MySQL connection: " + err.stack);
            return;
        }
        console.log("MySQL connection closed.");
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
